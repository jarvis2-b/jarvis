const apikeyInput = document.getElementById('apikey');
const voiceBtn = document.getElementById('voiceBtn');
const userInput = document.getElementById('userInput');
const sendBtn = document.getElementById('sendBtn');
const chatDiv = document.getElementById('chat');
const urlInput = document.getElementById('urlInput');
const goBtn = document.getElementById('goBtn');
const webview = document.getElementById('webview');

function appendMessage(text, who='assistant') {
  const el = document.createElement('div');
  el.textContent = text;
  el.className = who === 'user' ? 'chat-user' : 'chat-assistant';
  chatDiv.appendChild(el);
  chatDiv.scrollTop = chatDiv.scrollHeight;
}

async function sendMessage(text) {
  appendMessage(text, 'user');
  const apiKey = apikeyInput.value.trim();
  if (!apiKey) return appendMessage('Add API key to continue.');
  appendMessage('...thinking');
  try {
    const reply = await window.electronAPI.openaiChat({ apiKey, messages: [{ role: 'user', content: text }] });
    const last = chatDiv.querySelector('.chat-assistant:last-child');
    if (last && last.textContent === '...thinking') last.remove();
    appendMessage(reply, 'assistant');
    speak(reply);
  } catch (err) {
    appendMessage('Error: ' + err.message, 'assistant');
  }
}

sendBtn.addEventListener('click', () => {
  const v = userInput.value.trim();
  if (!v) return;
  sendMessage(v);
  userInput.value = '';
});

goBtn.addEventListener('click', () => {
  const v = urlInput.value.trim();
  if (!v) return;
  if (v.startsWith('http')) webview.src = v;
  else webview.src = 'https://www.google.com/search?q=' + encodeURIComponent(v);
});

// Text-to-speech
function speak(text) {
  if (!('speechSynthesis' in window)) return;
  const ut = new SpeechSynthesisUtterance(text);
  ut.rate = 1;
  window.speechSynthesis.cancel();
  window.speechSynthesis.speak(ut);
}

// Wake word + voice recognition setup
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
if (SpeechRecognition) {
  const recognizer = new SpeechRecognition();
  recognizer.continuous = true; // keep listening
  recognizer.interimResults = false;
  recognizer.lang = 'en-US';

  let waitingForWake = true;

  recognizer.onresult = (event) => {
    const result = event.results[event.results.length - 1];
    const transcript = result[0].transcript.trim().toLowerCase();
    console.log('Heard:', transcript);

    if (waitingForWake) {
      if (transcript.includes('hey jarvis')) {
        appendMessage('👂 Wake word detected! Listening for command...', 'assistant');
        waitingForWake = false;
      }
    } else {
      // treat as command
      if (transcript.length > 0) {
        userInput.value = transcript;
        sendMessage(transcript);
      }
      waitingForWake = true; // reset to wake mode
    }
  };

  recognizer.onerror = (event) => {
    appendMessage('Voice error: ' + event.error, 'assistant');
  };

  voiceBtn.addEventListener('click', () => {
    try {
      recognizer.start();
      appendMessage("🎧 Wake-word listening started. Say 'Hey Jarvis' to trigger.", 'assistant');
    } catch (e) {
      appendMessage('Voice start error: ' + e.message, 'assistant');
    }
  });
} else {
  voiceBtn.disabled = true;
  appendMessage('Voice recognition not supported in this environment.', 'assistant');
}

// keyboard shortcut
window.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && document.activeElement === userInput) sendBtn.click();
});
