const { app, BrowserWindow, ipcMain, shell } = require('electron');
const path = require('path');
const fetch = (...args) => import('node-fetch').then(m => m.default(...args));

function createWindow() {
  const win = new BrowserWindow({
    width: 1200,
    height: 800,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });
  win.loadFile('renderer.html');
}

app.whenReady().then(createWindow);
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

ipcMain.handle('openai-chat', async (event, { apiKey, messages, model='gpt-4o-mini' }) => {
  if (!apiKey) throw new Error('No API key provided');
  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiKey}` },
    body: JSON.stringify({ model, messages })
  });
  if (!response.ok) {
    const text = await response.text();
    throw new Error(`OpenAI error ${response.status}: ${text}`);
  }
  const data = await response.json();
  return data.choices?.[0]?.message?.content ?? JSON.stringify(data);
});

ipcMain.on('open-external', (ev, url) => { shell.openExternal(url); });
